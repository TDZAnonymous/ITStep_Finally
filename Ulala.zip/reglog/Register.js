

document.getElementById("submit").onclick = function () {
    location.href = "../OtherPages/main.html";
};
